<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ServiceInfo extends Model
{
    //
}
