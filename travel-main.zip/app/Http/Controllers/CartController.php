<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Cart;
use Session;
use Auth;

class CartController extends Controller
{
    
    public function addToCart(Request $request)
    {
        if ($request->isMethod('post')) {
            $data = $request->all();
            $cart = new Cart;
            $cart->user_id = auth()->user()->id;
            $cart->package_id = $data['package_id'];
            $cart->name = $data['name'];
            $cart->image = $data['image'];
            $cart->price = $data['price'];
            $cart->save();
         
            Session::flash('success_message',' Packages added to cart Successfully!');
            return redirect()->back();
         }
    }
}
