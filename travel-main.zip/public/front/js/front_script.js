$(document).ready(function(){
        //  alert('test');
        $("#sort").on('change',function(){
            var sort =  $("#sort").val();
            var category =  $("#category").val();
            if (sort === "" && url === "") {
                return false;
            }
            $.ajax({
                type: 'get',
                url: '/search',
                data: {
                    
                    category: category,
                    sort: sort,
                },
                success: function(response) {
                    console.log(response);
                    $("#ajaxPackage").html(response);
                },
                error: function() {
                    alert('error');
                }
            });
        });
});

$(document).ready(function(){
    // \\ alert('test');
    $("#average").on('change',function(){
        var average =  $("#average").val();
        var category =  $("#category").val();
        if (average === "" && url === "") {
            return false;
        }
        $.ajax({
            type: 'get',
            url: '/average',
            data: {
                
                category: category,
                average: average,
            },
            success: function(response) {
                console.log(response);
                $("#ajaxAverage").html(response);
            },
            error: function() {
                alert('error');
            }
        });
    });
});